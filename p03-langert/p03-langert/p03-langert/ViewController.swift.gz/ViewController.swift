//
//  ViewController.swift
//  p03-langert
//
//  Created by Erik Langert on 2/9/17.
//  Copyright © 2017 Erik Langert. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let p1 = Player()
        p1.draw()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

