//
//  Player.swift
//  p03-langert
//
//  Created by Erik Langert on 2/16/17.
//  Copyright © 2017 Erik Langert. All rights reserved.
//

import Foundation

class Player: Object {
    
}
